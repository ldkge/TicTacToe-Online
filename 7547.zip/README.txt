﻿Για την εκτέλεση του προγραμμάτος αρχικά φορτώστε τα project 

- TicTacToeClient
- TicTacToeOnline

και εκτελέστε πρώτα το TicTacToeOnline για να σηκωθεί ο server και έπειτα το TicTacToeClient. Για εκτέλεση στον ίδιο υπολογιστή δώστε για IP 127.0.0.1